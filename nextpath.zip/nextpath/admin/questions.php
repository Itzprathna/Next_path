<?php
require_once __DIR__ . '/../includes/admin_auth.php';

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name ASC')->fetchAll();

$filterCategory = (int)($_GET['category_id'] ?? 0);
$filterLevel = trim($_GET['level_group'] ?? '');
if (!in_array($filterLevel, ['all', 'high_school', 'higher_secondary', 'undergraduate', 'graduate', 'postgraduate'], true)) {
    $filterLevel = '';
}

try {
    // Filter by career field pointed to by ANY option weight (primary or
    // secondary), not by the legacy questions.category_id placeholder.
    $sql = 'SELECT DISTINCT q.id, q.question_text, q.option_e, q.created_at, q.level_group FROM questions q';
    $where = [];
    $params = [];
    if ($filterCategory > 0) {
        $where[] = 'EXISTS (SELECT 1 FROM question_option_weights w WHERE w.question_id = q.id AND w.category_id = ?)';
        $params[] = $filterCategory;
    }
    if ($filterLevel !== '') {
        $where[] = 'q.level_group = ?';
        $params[] = $filterLevel;
    }
    if (!empty($where)) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY q.created_at DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
} catch (PDOException $e) {
    // Installs predating the weighted/level migrations.
    $stmt = $pdo->query('
        SELECT q.id, q.question_text, q.option_e, q.created_at
        FROM questions q
        ORDER BY q.created_at DESC
    ');
    $filterLevel = '';
}
$questions = $stmt->fetchAll();

$page_title = 'Questions — NEXTPath Admin';
$active = 'questions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($page_title) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
</head>
<body class="dashboard-body">
<?php require __DIR__ . '/../includes/admin-sidebar.php'; ?>
<main class="dashboard-main">
  <header class="dashboard-header">
    <div>
      <h1>Questions</h1>
      <p class="dashboard-sub"><?= count($questions) ?> questions.</p>
    </div>
    <a href="add-question.php" class="btn btn-primary">Add Question</a>
  </header>

  <?php $flash = get_flash(); if ($flash): ?>
    <div class="flash flash-<?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
  <?php endif; ?>

  <section class="card">
    <form method="GET" action="questions.php" class="filter-bar">
      <label for="category_id">Filter by career field (any option points there)</label>
      <select id="category_id" name="category_id" onchange="this.form.submit()">
        <option value="0">All Fields</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $filterCategory === (int)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
      <label for="level_group">Level</label>
      <select id="level_group" name="level_group" onchange="this.form.submit()">
        <option value="">All Levels</option>
        <option value="all" <?= $filterLevel === 'all' ? 'selected' : '' ?>>Everyone</option>
        <option value="high_school" <?= $filterLevel === 'high_school' ? 'selected' : '' ?>>High School</option>
        <option value="higher_secondary" <?= $filterLevel === 'higher_secondary' ? 'selected' : '' ?>>Higher Secondary</option>
        <option value="undergraduate" <?= $filterLevel === 'undergraduate' ? 'selected' : '' ?>>Undergraduate</option>
        <option value="graduate" <?= $filterLevel === 'graduate' ? 'selected' : '' ?>>Graduate</option>
        <option value="postgraduate" <?= $filterLevel === 'postgraduate' ? 'selected' : '' ?>>Postgraduate</option>
      </select>
    </form>

    <div class="table-scroll">
      <table class="data-table">
        <thead>
          <tr><th>Question</th><th>Level</th><th>Options</th><th>Created</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach ($questions as $q): ?>
            <tr>
              <td><?= clean($q['question_text']) ?></td>
              <td><span class="badge"><?= clean($q['level_group'] ?? 'all') ?></span></td>
              <td><span class="badge"><?= !empty($q['option_e']) ? '5 options' : '4 options' ?></span></td>
              <td><?= date('d M Y', strtotime($q['created_at'])) ?></td>
              <td class="actions-cell">
                <a href="edit-question.php?id=<?= $q['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                <form method="POST" action="delete-question.php" class="confirm-form" data-confirm="Delete this question?">
                  <input type="hidden" name="id" value="<?= $q['id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($questions)): ?>
            <tr><td colspan="5">No questions found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </section>
</main>
<script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
