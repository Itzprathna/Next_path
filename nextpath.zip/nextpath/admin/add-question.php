<?php
require_once __DIR__ . '/../includes/admin_auth.php';

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name ASC')->fetchAll();
$letters = ['A', 'B', 'C', 'D', 'E'];
$errors = [];
$old = ['question_text' => '', 'option_a' => '', 'option_b' => '', 'option_c' => '', 'option_d' => '', 'option_e' => '', 'level_group' => 'all'];
$oldW = [];
foreach ($letters as $l) {
    $oldW[$l] = ['cat1' => '', 'w1' => '5', 'cat2' => '', 'w2' => '2'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $key => $_) {
        $old[$key] = trim($_POST[$key] ?? '');
    }
    foreach ($letters as $l) {
        $k = strtolower($l);
        $oldW[$l]['cat1'] = trim($_POST["cat1_{$k}"] ?? '');
        $oldW[$l]['w1']   = trim($_POST["w1_{$k}"] ?? '5');
        $oldW[$l]['cat2'] = trim($_POST["cat2_{$k}"] ?? '');
        $oldW[$l]['w2']   = trim($_POST["w2_{$k}"] ?? '2');
    }

    if (empty($old['question_text'])) $errors['question_text'] = 'Please enter the question.';
    if (!in_array($old['level_group'] ?? 'all', ['all', 'high_school', 'higher_secondary', 'undergraduate', 'graduate', 'postgraduate'], true)) {
        $errors['level_group'] = 'Invalid level group.';
        $old['level_group'] = 'all';
    }
    foreach (['option_a', 'option_b', 'option_c', 'option_d'] as $opt) {
        if (empty($old[$opt])) $errors[$opt] = 'Required.';
    }
    // Option E is optional; if given, it needs weights too.
    $hasE = !empty($old['option_e']);
    $activeLetters = $hasE ? $letters : ['A', 'B', 'C', 'D'];
    $validCatIds = array_map(fn($c) => (string)$c['id'], $categories);
    foreach ($activeLetters as $l) {
        $k = strtolower($l);
        if (empty($oldW[$l]['cat1']) || !in_array($oldW[$l]['cat1'], $validCatIds, true)) {
            $errors["cat1_{$k}"] = 'Pick the field this answer points to.';
        }
        if (!in_array($oldW[$l]['w1'], ['1', '2', '3', '4', '5'], true)) {
            $errors["w1_{$k}"] = 'Weight must be 1–5.';
        }
        if (!empty($oldW[$l]['cat2'])) {
            if (!in_array($oldW[$l]['cat2'], $validCatIds, true)) {
                $errors["cat2_{$k}"] = 'Invalid field.';
            } elseif ($oldW[$l]['cat2'] === $oldW[$l]['cat1']) {
                $errors["cat2_{$k}"] = 'Secondary field must differ from primary.';
            }
            if (!in_array($oldW[$l]['w2'], ['1', '2', '3', '4', '5'], true)) {
                $errors["w2_{$k}"] = 'Weight must be 1–5.';
            }
        }
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            // Legacy category_id column is kept for compatibility; store the
            // primary field of option A as a grouping placeholder. Scoring
            // never reads it — only question_option_weights matters.
            $stmt = $pdo->prepare('
                INSERT INTO questions (category_id, level_group, question_text, option_a, option_b, option_c, option_d, option_e, correct_answer)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)
            ');
            $stmt->execute([
                (int)$oldW['A']['cat1'], $old['level_group'], $old['question_text'],
                $old['option_a'], $old['option_b'], $old['option_c'], $old['option_d'],
                $hasE ? $old['option_e'] : null,
            ]);
            $qid = (int)$pdo->lastInsertId();
            $wstmt = $pdo->prepare('
                INSERT INTO question_option_weights (question_id, option_letter, category_id, weight)
                VALUES (?, ?, ?, ?)
            ');
            foreach ($activeLetters as $l) {
                $wstmt->execute([$qid, $l, (int)$oldW[$l]['cat1'], (int)$oldW[$l]['w1']]);
                if (!empty($oldW[$l]['cat2'])) {
                    $wstmt->execute([$qid, $l, (int)$oldW[$l]['cat2'], (int)$oldW[$l]['w2']]);
                }
            }
            $pdo->commit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[NEXTPath] Add question failed: ' . $e->getMessage());
            $errors['question_text'] = 'Something went wrong. Please try again.';
        }
        if (empty($errors)) {
            set_flash('success', 'Question added with career-field weights.');
            redirect('questions.php');
        }
    }
}

$page_title = 'Add Question — NEXTPath Admin';
$active = 'questions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($page_title) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
</head>
<body class="dashboard-body">
<?php require __DIR__ . '/../includes/admin-sidebar.php'; ?>
<main class="dashboard-main">
  <header class="dashboard-header">
    <div>
      <h1>Add Question</h1>
      <p class="dashboard-sub">No correct answer — each option points at the career field(s) it reveals, with a weight of 1–5.</p>
    </div>
  </header>

  <section class="card">
    <form method="POST" action="add-question.php" novalidate>
      <div class="form-group">
        <label for="level_group">Who sees this question?</label>
        <select id="level_group" name="level_group" required>
          <?php foreach (['all' => 'Everyone (shared general set)', 'high_school' => 'High School only', 'higher_secondary' => 'Higher Secondary only', 'undergraduate' => 'Undergraduate only', 'graduate' => 'Graduate only', 'postgraduate' => 'Postgraduate only'] as $val => $label): ?>
            <option value="<?= $val ?>" <?= $old['level_group'] === $val ? 'selected' : '' ?>><?= $label ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-error"><?= clean($errors['level_group'] ?? '') ?></span>
      </div>
      <div class="form-group">
        <label for="question_text">Question</label>
        <textarea id="question_text" name="question_text" rows="2" required><?= clean($old['question_text']) ?></textarea>
        <span class="field-error"><?= clean($errors['question_text'] ?? '') ?></span>
      </div>
      <?php foreach ($letters as $l): $k = strtolower($l); ?>
        <fieldset class="card" style="margin-bottom:12px;">
          <legend><strong>Option <?= $l ?><?= $l === 'E' ? ' (optional)' : '' ?></strong></legend>
          <div class="form-group">
            <label for="option_<?= $k ?>">Answer text</label>
            <input type="text" id="option_<?= $k ?>" name="option_<?= $k ?>" value="<?= clean($old["option_{$k}"]) ?>" <?= $l === 'E' ? '' : 'required' ?>>
            <span class="field-error"><?= clean($errors["option_{$k}"] ?? '') ?></span>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label for="cat1_<?= $k ?>">Primary career field (weight 1–5)</label>
              <select id="cat1_<?= $k ?>" name="cat1_<?= $k ?>">
                <option value="">Select field</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= $c['id'] ?>" <?= (string)$oldW[$l]['cat1'] === (string)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <span class="field-error"><?= clean($errors["cat1_{$k}"] ?? '') ?></span>
            </div>
            <div class="form-group">
              <label for="w1_<?= $k ?>">Primary weight</label>
              <select id="w1_<?= $k ?>" name="w1_<?= $k ?>">
                <?php foreach (['5','4','3','2','1'] as $wv): ?>
                  <option value="<?= $wv ?>" <?= $oldW[$l]['w1'] === $wv ? 'selected' : '' ?>><?= $wv ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="cat2_<?= $k ?>">Secondary field (optional)</label>
              <select id="cat2_<?= $k ?>" name="cat2_<?= $k ?>">
                <option value="">None</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= $c['id'] ?>" <?= (string)$oldW[$l]['cat2'] === (string)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <span class="field-error"><?= clean($errors["cat2_{$k}"] ?? '') ?></span>
            </div>
            <div class="form-group">
              <label for="w2_<?= $k ?>">Secondary weight</label>
              <select id="w2_<?= $k ?>" name="w2_<?= $k ?>">
                <?php foreach (['2','3','1','4','5'] as $wv): ?>
                  <option value="<?= $wv ?>" <?= $oldW[$l]['w2'] === $wv ? 'selected' : '' ?>><?= $wv ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </fieldset>
      <?php endforeach; ?>
      <button type="submit" class="btn btn-primary">Save Question</button>
      <a href="questions.php" class="btn btn-outline">Cancel</a>
    </form>
  </section>
</main>
<script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
