<?php
require_once __DIR__ . '/../includes/admin_auth.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM questions WHERE id = ?');
$stmt->execute([$id]);
$question = $stmt->fetch();

if (!$question) {
    set_flash('error', 'Question not found.');
    redirect('questions.php');
}

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name ASC')->fetchAll();
$letters = ['A', 'B', 'C', 'D', 'E'];

// Existing weights, grouped: [letter] => list of rows
$wstmt = $pdo->prepare('SELECT option_letter, category_id, weight FROM question_option_weights WHERE question_id = ? ORDER BY option_letter');
$wstmt->execute([$id]);
$existing = [];
foreach ($wstmt->fetchAll() as $row) {
    $existing[strtoupper($row['option_letter'])][] = $row;
}

$errors = [];
$old = [
    'question_text' => $question['question_text'],
    'option_a' => $question['option_a'], 'option_b' => $question['option_b'],
    'option_c' => $question['option_c'], 'option_d' => $question['option_d'],
    'option_e' => $question['option_e'] ?? '',
    'level_group' => $question['level_group'] ?? 'all',
];
$oldW = [];
foreach ($letters as $l) {
    $rows = $existing[$l] ?? [];
    $oldW[$l] = [
        'cat1' => (string)($rows[0]['category_id'] ?? ''),
        'w1'   => (string)($rows[0]['weight'] ?? '5'),
        'cat2' => (string)($rows[1]['category_id'] ?? ''),
        'w2'   => (string)($rows[1]['weight'] ?? '2'),
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['question_text'] = trim($_POST['question_text'] ?? '');
    $old['level_group'] = trim($_POST['level_group'] ?? 'all');
    if (!in_array($old['level_group'], ['all', 'high_school', 'higher_secondary', 'undergraduate', 'graduate', 'postgraduate'], true)) {
        $old['level_group'] = 'all';
    }
    foreach (['a','b','c','d','e'] as $k) {
        $old["option_{$k}"] = trim($_POST["option_{$k}"] ?? '');
    }
    foreach ($letters as $l) {
        $k = strtolower($l);
        $oldW[$l]['cat1'] = trim($_POST["cat1_{$k}"] ?? '');
        $oldW[$l]['w1']   = trim($_POST["w1_{$k}"] ?? '5');
        $oldW[$l]['cat2'] = trim($_POST["cat2_{$k}"] ?? '');
        $oldW[$l]['w2']   = trim($_POST["w2_{$k}"] ?? '2');
    }

    if (empty($old['question_text'])) $errors['question_text'] = 'Please enter the question.';
    foreach (['option_a', 'option_b', 'option_c', 'option_d'] as $opt) {
        if (empty($old[$opt])) $errors[$opt] = 'Required.';
    }
    $hasE = !empty($old['option_e']);
    $activeLetters = $hasE ? $letters : ['A', 'B', 'C', 'D'];
    $validCatIds = array_map(fn($c) => (string)$c['id'], $categories);
    foreach ($activeLetters as $l) {
        $k = strtolower($l);
        if (empty($oldW[$l]['cat1']) || !in_array($oldW[$l]['cat1'], $validCatIds, true)) {
            $errors["cat1_{$k}"] = 'Pick the field this answer points to.';
        }
        if (!in_array($oldW[$l]['w1'], ['1', '2', '3', '4', '5'], true)) {
            $errors["w1_{$k}"] = 'Weight must be 1–5.';
        }
        if (!empty($oldW[$l]['cat2'])) {
            if (!in_array($oldW[$l]['cat2'], $validCatIds, true)) {
                $errors["cat2_{$k}"] = 'Invalid field.';
            } elseif ($oldW[$l]['cat2'] === $oldW[$l]['cat1']) {
                $errors["cat2_{$k}"] = 'Secondary field must differ from primary.';
            }
            if (!in_array($oldW[$l]['w2'], ['1', '2', '3', '4', '5'], true)) {
                $errors["w2_{$k}"] = 'Weight must be 1–5.';
            }
        }
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('
                UPDATE questions SET category_id = ?, level_group = ?, question_text = ?, option_a = ?, option_b = ?,
                option_c = ?, option_d = ?, option_e = ?, correct_answer = NULL WHERE id = ?
            ');
            $stmt->execute([
                (int)$oldW['A']['cat1'], $old['level_group'], $old['question_text'],
                $old['option_a'], $old['option_b'], $old['option_c'], $old['option_d'],
                $hasE ? $old['option_e'] : null, $id,
            ]);
            $pdo->prepare('DELETE FROM question_option_weights WHERE question_id = ?')->execute([$id]);
            $wstmt = $pdo->prepare('
                INSERT INTO question_option_weights (question_id, option_letter, category_id, weight)
                VALUES (?, ?, ?, ?)
            ');
            foreach ($activeLetters as $l) {
                $wstmt->execute([$id, $l, (int)$oldW[$l]['cat1'], (int)$oldW[$l]['w1']]);
                if (!empty($oldW[$l]['cat2'])) {
                    $wstmt->execute([$id, $l, (int)$oldW[$l]['cat2'], (int)$oldW[$l]['w2']]);
                }
            }
            $pdo->commit();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[NEXTPath] Edit question failed: ' . $e->getMessage());
            $errors['question_text'] = 'Something went wrong. Please try again.';
        }
        if (empty($errors)) {
            set_flash('success', 'Question updated with career-field weights.');
            redirect('questions.php');
        }
    }
}

$page_title = 'Edit Question — NEXTPath Admin';
$active = 'questions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($page_title) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
</head>
<body class="dashboard-body">
<?php require __DIR__ . '/../includes/admin-sidebar.php'; ?>
<main class="dashboard-main">
  <header class="dashboard-header">
    <div>
      <h1>Edit Question</h1>
      <p class="dashboard-sub">Each option keeps its own career-field weights — the letter itself scores nothing.</p>
    </div>
  </header>

  <section class="card">
    <form method="POST" action="edit-question.php?id=<?= $id ?>" novalidate>
      <input type="hidden" name="id" value="<?= $id ?>">
      <div class="form-group">
        <label for="level_group">Who sees this question?</label>
        <select id="level_group" name="level_group" required>
          <?php foreach (['all' => 'Everyone (shared general set)', 'high_school' => 'High School only', 'higher_secondary' => 'Higher Secondary only', 'undergraduate' => 'Undergraduate only', 'graduate' => 'Graduate only', 'postgraduate' => 'Postgraduate only'] as $val => $label): ?>
            <option value="<?= $val ?>" <?= $old['level_group'] === $val ? 'selected' : '' ?>><?= $label ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="question_text">Question</label>
        <textarea id="question_text" name="question_text" rows="2" required><?= clean($old['question_text']) ?></textarea>
        <span class="field-error"><?= clean($errors['question_text'] ?? '') ?></span>
      </div>
      <?php foreach ($letters as $l): $k = strtolower($l); ?>
        <fieldset class="card" style="margin-bottom:12px;">
          <legend><strong>Option <?= $l ?><?= $l === 'E' ? ' (optional)' : '' ?></strong></legend>
          <div class="form-group">
            <label for="option_<?= $k ?>">Answer text</label>
            <input type="text" id="option_<?= $k ?>" name="option_<?= $k ?>" value="<?= clean($old["option_{$k}"]) ?>" <?= $l === 'E' ? '' : 'required' ?>>
            <span class="field-error"><?= clean($errors["option_{$k}"] ?? '') ?></span>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label for="cat1_<?= $k ?>">Primary career field</label>
              <select id="cat1_<?= $k ?>" name="cat1_<?= $k ?>">
                <option value="">Select field</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= $c['id'] ?>" <?= (string)$oldW[$l]['cat1'] === (string)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <span class="field-error"><?= clean($errors["cat1_{$k}"] ?? '') ?></span>
            </div>
            <div class="form-group">
              <label for="w1_<?= $k ?>">Primary weight</label>
              <select id="w1_<?= $k ?>" name="w1_<?= $k ?>">
                <?php foreach (['5','4','3','2','1'] as $wv): ?>
                  <option value="<?= $wv ?>" <?= $oldW[$l]['w1'] === $wv ? 'selected' : '' ?>><?= $wv ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label for="cat2_<?= $k ?>">Secondary field (optional)</label>
              <select id="cat2_<?= $k ?>" name="cat2_<?= $k ?>">
                <option value="">None</option>
                <?php foreach ($categories as $c): ?>
                  <option value="<?= $c['id'] ?>" <?= (string)$oldW[$l]['cat2'] === (string)$c['id'] ? 'selected' : '' ?>><?= clean($c['name']) ?></option>
                <?php endforeach; ?>
              </select>
              <span class="field-error"><?= clean($errors["cat2_{$k}"] ?? '') ?></span>
            </div>
            <div class="form-group">
              <label for="w2_<?= $k ?>">Secondary weight</label>
              <select id="w2_<?= $k ?>" name="w2_<?= $k ?>">
                <?php foreach (['2','3','1','4','5'] as $wv): ?>
                  <option value="<?= $wv ?>" <?= $oldW[$l]['w2'] === $wv ? 'selected' : '' ?>><?= $wv ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </fieldset>
      <?php endforeach; ?>
      <button type="submit" class="btn btn-primary">Update Question</button>
      <a href="questions.php" class="btn btn-outline">Cancel</a>
    </form>
  </section>
</main>
<script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
