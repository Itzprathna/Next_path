<?php
/**
 * NEXTPath - Shared helper functions
 * Sanitisation, redirects, flash messages, scoring and
 * career recommendation logic all live here so pages stay thin.
 */

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ---------------------------------------------------------
 * Basic helpers
 * ------------------------------------------------------- */

function clean($value) {
    return htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header("Location: {$path}");
    exit;
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function is_logged_in() {
    return !empty($_SESSION['user_id']);
}

function current_user_id() {
    return $_SESSION['user_id'] ?? null;
}

function current_user_role() {
    return $_SESSION['role'] ?? null;
}

/**
 * Works out the app's base path automatically from the folder it's
 * actually installed in (e.g. "/nextpath/", "/nextpath3/"), instead of
 * assuming the folder is always literally named "nextpath". This is
 * what makes every base_url() link, redirect and asset path correct
 * no matter what you rename the project folder to.
 */
if (!defined('APP_BASE_PATH')) {
    $appRoot = str_replace('\\', '/', dirname(__DIR__)); // parent of includes/
    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
    $relative = ($docRoot !== '' && strpos($appRoot, $docRoot) === 0)
        ? substr($appRoot, strlen($docRoot))
        : '';
    define('APP_BASE_PATH', $relative === '' ? '/' : rtrim($relative, '/') . '/');
}

function base_url($path = '') {
    return APP_BASE_PATH . ltrim($path, '/');
}

/* ---------------------------------------------------------
 * Password security
 * ------------------------------------------------------- */

function hash_password($plain) {
    return password_hash($plain, PASSWORD_DEFAULT);
}

function verify_password($plain, $hash) {
    return password_verify($plain, $hash);
}

/* ---------------------------------------------------------
 * Settings (e.g. assessment_length) — editable without code changes
 * ------------------------------------------------------- */

function get_setting($pdo, $key, $default = null) {
    $stmt = $pdo->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['setting_value'] : $default;
}

/* ---------------------------------------------------------
 * Assessment: question selection
 * Picks up to $limit questions, shuffled so that categories
 * are interleaved rather than grouped together.
 * ------------------------------------------------------- */

/**
 * Maps a user's education_level to its own question pool. Every level
 * gets a distinct set: level-specific questions first, then shared
 * general ('all') questions to fill the assessment length.
 *   High School       → high_school
 *   Higher Secondary  → higher_secondary
 *   Undergraduate     → undergraduate
 *   Graduate          → graduate
 *   Postgraduate      → postgraduate
 *   anything else     → null (no preference, legacy random bank)
 */
function level_group_for_education($educationLevel) {
    static $map = [
        'high school'     => 'high_school',
        'higher secondary'=> 'higher_secondary',
        'undergraduate'   => 'undergraduate',
        'graduate'        => 'graduate',
        'postgraduate'    => 'postgraduate',
    ];
    $l = strtolower(trim((string)$educationLevel));
    return $map[$l] ?? null;
}

function get_assessment_questions($pdo, $limit, $levelGroup = null) {
    // Education-level-wise sets: level-specific questions first, then
    // shared general ('all') questions to fill the assessment length.
    // Scoring never reads level_group — only question_option_weights.
    $limit = max(1, (int)$limit);
    $levelGroup = in_array($levelGroup, ['high_school', 'higher_secondary', 'undergraduate', 'graduate', 'postgraduate'], true) ? $levelGroup : null;
    if ($levelGroup !== null) {
        try {
            $stmt = $pdo->prepare('SELECT q.* FROM questions q WHERE q.level_group = ? ORDER BY RAND()');
            $stmt->execute([$levelGroup]);
            $specific = $stmt->fetchAll();
            $general = $pdo->query("SELECT q.* FROM questions q WHERE q.level_group = 'all' ORDER BY RAND()")->fetchAll();
            $picked = array_slice($specific, 0, $limit);
            $picked = array_merge($picked, array_slice($general, 0, $limit - count($picked)));
            shuffle($picked);
            if (!empty($picked)) {
                return array_slice($picked, 0, $limit);
            }
            // Pool too small (e.g. admin deleted questions) — fall through
            // to the legacy behaviour below rather than failing.
        } catch (PDOException $e) {
            // Installs predating migration v4 have no level_group column.
            error_log('[NEXTPath] level-wise selection unavailable: ' . $e->getMessage());
        }
    }
    // Interest-based assessment: questions carry no visible category and no
    // correct answer. A simple random sample is correct here — the old
    // round-robin by category grouping belonged to the quiz model and is
    // intentionally removed.
    $stmt = $pdo->prepare('SELECT q.* FROM questions q ORDER BY RAND() LIMIT ' . $limit);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Returns all scoring weights for the given questions:
 *   [question_id][option_letter] => [['category_id' => n, 'weight' => n], ...]
 * Gracefully returns [] when the weights table does not exist yet
 * (fresh install that hasn't run the v3 migration).
 */
function get_question_weights($pdo, array $questionIds) {
    if (empty($questionIds)) {
        return [];
    }
    try {
        $in = implode(',', array_fill(0, count($questionIds), '?'));
        $stmt = $pdo->prepare("
            SELECT question_id, option_letter, category_id, weight
            FROM question_option_weights
            WHERE question_id IN ($in)
            ORDER BY question_id, option_letter
        ");
        $stmt->execute(array_values($questionIds));
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log('[NEXTPath] weights lookup failed: ' . $e->getMessage());
        return [];
    }
    $map = [];
    foreach ($rows as $r) {
        $map[(int)$r['question_id']][strtoupper($r['option_letter'])][] = [
            'category_id' => (int)$r['category_id'],
            'weight'      => (int)$r['weight'],
        ];
    }
    return $map;
}

/* ---------------------------------------------------------
 * Assessment: scoring
 * ------------------------------------------------------- */

/**
 * Interest-based scoring (weighted).
 *
 * Each selected answer contributes its predefined weights to the relevant
 * career fields. Final percentage per field:
 *
 *   score = earned / max_possible * 100
 *
 * where max_possible for a field = sum over this assessment's questions of
 * the highest weight that field could have earned on each question.
 * This keeps percentages mathematically meaningful: unrelated fields stay
 * near zero, related fields cluster together, and repeating one letter
 * cannot produce 100% everywhere because letters map to different fields
 * on different questions.
 *
 * Returns an array keyed by category_id:
 *   [category_id => ['name' => ..., 'correct' => earned, 'total' => max, 'score' => pct]]
 * ('correct'/'total' keys are kept so existing templates keep working;
 * they now mean earned points / max points, not right answers.)
 */
function get_category_scores($pdo, $assessment_id) {
    // Which questions were answered, and what was selected?
    $stmt = $pdo->prepare('SELECT question_id, selected_answer FROM assessment_answers WHERE assessment_id = ?');
    $stmt->execute([$assessment_id]);
    $answers = $stmt->fetchAll();
    if (empty($answers)) {
        return [];
    }
    $questionIds = array_values(array_unique(array_map(fn($a) => (int)$a['question_id'], $answers)));
    $weights = get_question_weights($pdo, $questionIds);

    // Fallback: weights table missing/empty (legacy data) — use old
    // correctness model so historic pages never fatal-error.
    if (empty($weights)) {
        $stmt = $pdo->prepare('
            SELECT c.id AS category_id, c.name,
                   SUM(aa.is_correct) AS correct,
                   COUNT(*) AS total
            FROM assessment_answers aa
            JOIN questions q ON q.id = aa.question_id
            JOIN categories c ON c.id = q.category_id
            WHERE aa.assessment_id = ?
            GROUP BY c.id, c.name
        ');
        $stmt->execute([$assessment_id]);
        $rows = $stmt->fetchAll();
        $result = [];
        foreach ($rows as $row) {
            $score = $row['total'] > 0 ? round(($row['correct'] / $row['total']) * 100, 1) : 0;
            $result[$row['category_id']] = [
                'name'    => $row['name'],
                'correct' => (int)$row['correct'],
                'total'   => (int)$row['total'],
                'score'   => $score,
            ];
        }
        uasort($result, fn($a, $b) => $b['score'] <=> $a['score']);
        return $result;
    }

    // Max possible per category for THIS question set.
    $maxPerCategory = [];
    foreach ($questionIds as $qid) {
        $bestForQuestion = [];
        foreach (($weights[$qid] ?? []) as $letter => $entries) {
            foreach ($entries as $e) {
                $cid = $e['category_id'];
                $bestForQuestion[$cid] = max($bestForQuestion[$cid] ?? 0, $e['weight']);
            }
        }
        foreach ($bestForQuestion as $cid => $w) {
            $maxPerCategory[$cid] = ($maxPerCategory[$cid] ?? 0) + $w;
        }
    }

    // Earned points from the user's actual selections.
    $earnedPerCategory = [];
    foreach ($answers as $a) {
        $qid = (int)$a['question_id'];
        $letter = strtoupper(trim($a['selected_answer'] ?? ''));
        foreach (($weights[$qid][$letter] ?? []) as $e) {
            $earnedPerCategory[$e['category_id']] = ($earnedPerCategory[$e['category_id']] ?? 0) + $e['weight'];
        }
    }

    $catIds = array_unique(array_merge(array_keys($maxPerCategory), array_keys($earnedPerCategory)));
    if (empty($catIds)) {
        return [];
    }
    $in = implode(',', array_fill(0, count($catIds), '?'));
    $stmt = $pdo->prepare("SELECT id, name FROM categories WHERE id IN ($in)");
    $stmt->execute(array_values($catIds));
    $names = [];
    foreach ($stmt->fetchAll() as $row) {
        $names[(int)$row['id']] = $row['name'];
    }

    $result = [];
    foreach ($catIds as $cid) {
        $max = $maxPerCategory[$cid] ?? 0;
        $earned = $earnedPerCategory[$cid] ?? 0;
        $score = $max > 0 ? round(($earned / $max) * 100, 1) : 0;
        $result[$cid] = [
            'name'    => $names[$cid] ?? ('Field ' . $cid),
            'correct' => $earned,
            'total'   => $max,
            'score'   => $score,
        ];
    }
    uasort($result, fn($a, $b) => $b['score'] <=> $a['score']);
    return $result;
}

/**
 * Builds the skill profile (e.g. Analytical Thinking, Communication...)
 * by averaging the scores of every category mapped to that skill.
 */
function get_skill_profile($pdo, $category_scores) {
    if (empty($category_scores)) {
        return [];
    }
    $catIds = array_keys($category_scores);
    $in = implode(',', array_fill(0, count($catIds), '?'));
    $stmt = $pdo->prepare("SELECT category_id, skill_name, weight FROM category_skills WHERE category_id IN ($in)");
    $stmt->execute($catIds);
    $mappings = $stmt->fetchAll();

    $skillTotals = [];
    $skillWeights = [];
    foreach ($mappings as $m) {
        $cid = $m['category_id'];
        if (!isset($category_scores[$cid])) {
            continue;
        }
        $skill = $m['skill_name'];
        $weight = (float)$m['weight'];
        $skillTotals[$skill] = ($skillTotals[$skill] ?? 0) + ($category_scores[$cid]['score'] * $weight);
        $skillWeights[$skill] = ($skillWeights[$skill] ?? 0) + $weight;
    }

    $profile = [];
    foreach ($skillTotals as $skill => $total) {
        $profile[$skill] = round($total / $skillWeights[$skill], 1);
    }
    arsort($profile);
    return $profile;
}

function skill_level_label($score) {
    if ($score >= 85) return 'Excellent';
    if ($score >= 70) return 'Strong';
    if ($score >= 55) return 'Good';
    return 'Developing';
}

/* ---------------------------------------------------------
 * Career recommendation algorithm
 * Career Match = Category Score x Career Relevance
 * Centralised here so the formula can evolve in one place.
 * ------------------------------------------------------- */

function get_career_recommendations($pdo, $category_scores, $limit = 6) {
    if (empty($category_scores)) {
        return [];
    }
    $catIds = array_keys($category_scores);
    $in = implode(',', array_fill(0, count($catIds), '?'));
    $stmt = $pdo->prepare("
        SELECT ca.id, ca.career_name, ca.description, ca.relevance, ca.category_id, c.name AS category_name
        FROM careers ca
        JOIN categories c ON c.id = ca.category_id
        WHERE ca.category_id IN ($in)
    ");
    $stmt->execute($catIds);
    $careers = $stmt->fetchAll();

    $recommendations = [];
    foreach ($careers as $career) {
        $categoryScore = $category_scores[$career['category_id']]['score'];
        $match = round($categoryScore * (float)$career['relevance'], 1);
        $match = min($match, 100);
        $recommendations[] = [
            'career_name'   => $career['career_name'],
            'description'   => $career['description'],
            'category_id'   => $career['category_id'],
            'category_name' => $career['category_name'],
            'match'         => $match,
        ];
    }

    usort($recommendations, fn($a, $b) => $b['match'] <=> $a['match']);
    return array_slice($recommendations, 0, $limit);
}

/* ---------------------------------------------------------
 * College / Course Recommendations
 * ------------------------------------------------------- */

function get_courses_for_categories($pdo, $categoryIds) {
    if (empty($categoryIds)) {
        return [];
    }
    try {
        $in = implode(',', array_fill(0, count($categoryIds), '?'));
        $stmt = $pdo->prepare("SELECT category_id, course_name, description FROM courses WHERE category_id IN ($in) ORDER BY course_name ASC");
        $stmt->execute($categoryIds);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        // The courses table may not exist yet on installs that haven't
        // run database/migration_v2_courses.sql. Degrade gracefully
        // instead of taking down the whole page.
        error_log('[NEXTPath] courses lookup failed: ' . $e->getMessage());
        return [];
    }

    $byCategory = [];
    foreach ($rows as $row) {
        $byCategory[$row['category_id']][] = $row;
    }
    return $byCategory;
}

/* ---------------------------------------------------------
 * Validation helpers (server-side — never trust JS alone)
 * ------------------------------------------------------- */

function validate_registration($data) {
    $errors = [];

    if (empty($data['full_name']) || strlen(trim($data['full_name'])) < 2) {
        $errors['full_name'] = 'Please enter your full name.';
    }
    if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (empty($data['mobile']) || !preg_match('/^[0-9]{10}$/', $data['mobile'])) {
        $errors['mobile'] = 'Please enter a valid 10-digit mobile number.';
    }
    if (empty($data['password']) || strlen($data['password']) < 6) {
        $errors['password'] = 'Password must be at least 6 characters.';
    }
    if (empty($data['gender']) || !in_array($data['gender'], ['Male', 'Female', 'Other'], true)) {
        $errors['gender'] = 'Please select a gender.';
    }
    if (empty($data['education_level'])) {
        $errors['education_level'] = 'Please select an education level.';
    }
    if (empty($data['college_name'])) {
        $errors['college_name'] = 'Please enter your school or college name.';
    }

    return $errors;
}
