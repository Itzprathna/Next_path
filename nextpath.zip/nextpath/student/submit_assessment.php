<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SESSION['assessment_question_ids'])) {
    redirect('assessment.php');
}

$questionIds = array_values(array_unique(array_map('intval', $_SESSION['assessment_question_ids'])));
$userId = current_user_id();

if (empty($questionIds)) {
    set_flash('error', 'No assessment questions were found. Please try again.');
    redirect('assessment.php');
}

// Load the weights for exactly the questions the student saw.
$weights = get_question_weights($pdo, $questionIds);
if (empty($weights)) {
    error_log('[NEXTPath] Assessment submitted without weights; question set may predate the v3 migration.');
    set_flash('error', 'This assessment can no longer be scored. Please start a new one.');
    redirect('assessment.php');
}

// Validate every answer: it must be one of the letters actually offered
// for that question (some questions have 4 options, most have 5).
$in = implode(',', array_fill(0, count($questionIds), '?'));
$stmt = $pdo->prepare("SELECT id, option_e FROM questions WHERE id IN ($in)");
$stmt->execute($questionIds);
$offered = [];
foreach ($stmt->fetchAll() as $row) {
    $letters = ['A', 'B', 'C', 'D'];
    if (!empty($row['option_e'])) {
        $letters[] = 'E';
    }
    $offered[(int)$row['id']] = $letters;
}

$answers = [];
foreach ($questionIds as $qid) {
    $selected = strtoupper(trim($_POST["q_{$qid}"] ?? ''));
    if (!isset($offered[$qid]) || !in_array($selected, $offered[$qid], true)) {
        set_flash('error', 'Please answer every question before submitting.');
        redirect('assessment.php');
    }
    // Points contributed by this single answer (primary + any secondary).
    $points = 0;
    foreach (($weights[$qid][$selected] ?? []) as $entry) {
        $points += (int)$entry['weight'];
    }
    $answers[] = [
        'question_id' => $qid,
        'selected'    => $selected,
        'score'       => $points,
    ];
}

$totalQuestions = count($questionIds);

try {
    $pdo->beginTransaction();

    // overall_score / correct_answers are filled in after scoring below.
    $stmt = $pdo->prepare('
        INSERT INTO assessments (user_id, total_questions, correct_answers, overall_score)
        VALUES (?, ?, 0, 0)
    ');
    $stmt->execute([$userId, $totalQuestions]);
    $assessmentId = (int)$pdo->lastInsertId();

    $stmt = $pdo->prepare('
        INSERT INTO assessment_answers (assessment_id, question_id, selected_answer, is_correct, score)
        VALUES (?, ?, ?, 0, ?)
    ');
    foreach ($answers as $a) {
        $stmt->execute([$assessmentId, $a['question_id'], $a['selected'], $a['score']]);
    }

    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('[NEXTPath] Assessment submit failed: ' . $e->getMessage());
    set_flash('error', 'Something went wrong. Please try again.');
    redirect('assessment.php');
}

// Score the just-saved assessment with the weighted model and store the
// headline figure: the top career-field match percentage. There is no
// "correct answer" any more, so correct_answers stays 0 by design and the
// assessments table keeps its shape for history/admin pages.
$categoryScores = get_category_scores($pdo, $assessmentId);
$topMatch = 0;
if (!empty($categoryScores)) {
    $top = array_values($categoryScores)[0];
    $topMatch = (float)$top['score'];
}
$stmt = $pdo->prepare('UPDATE assessments SET overall_score = ? WHERE id = ?');
$stmt->execute([round($topMatch, 2), $assessmentId]);

unset($_SESSION['assessment_question_ids']);
redirect("result.php?id={$assessmentId}");
